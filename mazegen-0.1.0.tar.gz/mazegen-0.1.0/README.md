# Maze Grid — Core Module

The core data model and maze-generation logic for the A-Maze-ing project.
Contains two classes — `Cell` and `Grid` — that together handle maze structure,
DFS-based generation, imperfection passes, and optional "42" pattern embedding.

---

## Cell

Represents a single tile in the maze grid.

Each cell stores its walls as a 4-bit bitmask and tracks whether it has been
visited during generation.

### Wall bitmask

| Bit | Hex  | Direction |
|-----|------|-----------|
| 0   | `0x1` | North    |
| 1   | `0x2` | East     |
| 2   | `0x4` | South    |
| 3   | `0x8` | West     |

A freshly created cell has all walls set (`0xf`). Removing a wall clears the
corresponding bit; adding one sets it.

### Methods

| Method | Description |
|--------|-------------|
| `visit()` | Marks the cell as visited. |
| `remove_wall(direction)` | Clears the wall bit for the given direction. |
| `add_wall(direction)` | Sets the wall bit for the given direction. |

---

## Grid

Represents the full maze — a 2-D list of `Cell` objects — and provides all
generation and mutation operations.

### Constructor

```python
Grid(width, height, start, end)
```

- `width`, `height` — dimensions in cells.
- `start`, `end` — `(row, col)` tuples for the maze entrance and exit.

The grid pre-computes a center cell (`center_i`, `center_j`) used for placing
the 42 pattern. For even dimensions the center is shifted one cell toward the
top-left so the pattern region always fits.

---

### Wall query helpers

These return `True` if the named wall is present on cell `(i, j)`.

```python
grid.north(i, j)
grid.east(i, j)
grid.south(i, j)
grid.west(i, j)
```

All four return `False` for out-of-bounds coordinates.

---

### 42 pattern

A hardcoded 5 × 7 pixel-art bitmap of "42" is stored as a list of bitmask rows.
Cells that are fully enclosed (`0x1`, all walls) act as solid pixels; all other
values encode open passages.

**`pattern() -> bool`**
Returns `True` (and sets `pattern_state`) if the grid is large enough to embed
the pattern (width > 8 **and** height > 8).

**`add_pattern(flag=False) -> bool`**
Stamps the pattern into the center of the grid.

- Cells that are solid pixels are marked as visited so the DFS generator skips
  them, leaving them as walls.
- When `flag=True`, non-solid cells inside the 7 × 5 region also have their
  wall bitmasks written directly, producing visible passages that form the
  numeral shapes.
- Returns `False` (and prints an error) if `start` or `end` would land on a
  solid pixel, which would trap the entrance or exit.

---

### Generation

**`generate(render_flag=False) -> Generator`**

Generates a perfect maze using iterative DFS (recursive backtracker).

Starting from `start`, the algorithm:
1. Visits the current cell and picks a random unvisited neighbour.
2. Removes the shared wall between the two cells (both sides).
3. Pushes the new cell onto the stack and moves to it.
4. When no unvisited neighbours are available, pops back up the stack.

If `pattern_state` is set, `add_pattern(True)` is called first so the "42"
region is pre-carved before generation begins.

When `render_flag=True` the generator yields the full cell grid after every
step, enabling live animation. Otherwise it yields once at the end.

---

### Imperfection pass

A perfect maze has exactly one path between any two cells. The imperfection
pass randomly removes extra walls to create additional routes, making the maze
more interesting to solve.

**`seek_and_destroy(render_flag=False) -> Generator`**

Divides the grid into up to eight rectangular regions around the 42 pattern
area (skipping the center region that contains the pattern) and calls
`wall_destroyer` on each. On small grids (width or height ≤ 8) the entire grid
is treated as a single region.

The number of destructions per region scales with grid area:
`count = width * height // 100 + 1`.

**`wall_destroyer(rt, ct, count)`**

Picks `count` random cells within the rectangle defined by row range `rt` and
column range `ct`, then removes one wall between the cell and a random
accessible neighbour. Falls back after 8 failed attempts to find a cell with
available neighbours.

---

### Utilities

**`get(i, j) -> Cell | None`**
Returns the cell at `(i, j)`, or `None` for out-of-bounds coordinates.

**`get_neighbour(i, j) -> list[tuple[int, int]]`**
Returns coordinates of all unvisited neighbours that are not blocked by a wall
from the current cell's side. Used by both the generator and the wall destroyer.

**`set_beck()`**
Resets `visited` to `False` on every cell. Called before the imperfection pass
so `get_neighbour` behaves correctly in that context.

**`change_grid(matrix)`**
Replaces the wall bitmask of every cell with values from `matrix`. Useful for
loading a saved maze state.

---

## Typical usage

```python
grid = Grid(width=21, height=15, start=(0, 0), end=(14, 20))

if grid.pattern():
    pass  # pattern will be embedded automatically during generate()

# Generate — consume the generator to drive animation or just exhaust it
for state in grid.generate(render_flag=False):
    pass  # state is the full cells matrix after generation

# Optional: make the maze imperfect
for state in grid.seek_and_destroy(render_flag=False):
    pass
```

For live rendering, pass `render_flag=True` to either generator and display
each yielded frame.